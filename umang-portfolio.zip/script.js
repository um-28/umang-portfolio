// Minimal JS functionality (if needed in future)
console.log("Portfolio Loaded");